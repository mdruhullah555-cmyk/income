package com.example.data.remote

import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class SavingsTipItem(
    val title: String,
    val detail: String,
    val targetCategory: String,
    val estimatedMonthlySaving: String,
    val impactLevel: String
)

data class PersonalizedSavingsReport(
    val healthScore: Int,
    val headline: String,
    val summary: String,
    val tips: List<SavingsTipItem>
)

class AiSavingsRepository {

    private val structuredSchema = Schema.obj(
        properties = mapOf(
            "healthScore" to Schema.integer(description = "Financial health score from 0 to 100 based on savings rate, budget adherence, and expense diversity."),
            "headline" to Schema.string(description = "A concise 4-8 word summary headline of the user's current spending habits."),
            "summary" to Schema.string(description = "2-sentence overview highlighting strengths and top opportunity to save."),
            "tips" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "title" to Schema.string(description = "Short actionable tip title"),
                        "detail" to Schema.string(description = "Specific advice referencing the user's actual category spend and habits"),
                        "targetCategory" to Schema.string(description = "Relevant expense category or Savings"),
                        "estimatedMonthlySaving" to Schema.string(description = "Estimated monthly savings formatted with currency symbol"),
                        "impactLevel" to Schema.enumeration(
                            values = listOf("High", "Medium", "Quick Win"),
                            description = "Impact priority"
                        )
                    )
                ),
                description = "3 to 5 personalized, concrete savings tips tailored to the user's actual spending data."
            )
        )
    )

    private val structuredModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = structuredSchema
            }
        )
    }

    private val coachChatModel by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    suspend fun generateSavingsReport(financialSnapshotPrompt: String): PersonalizedSavingsReport {
        val response = withTimeout(60_000L) {
            structuredModel.generateContent(financialSnapshotPrompt)
        }
        val jsonText = response.text
            ?: throw IllegalStateException("AI Coach returned an empty response.")

        val json = JSONObject(jsonText)
        val healthScore = json.optInt("healthScore", 70).coerceIn(0, 100)
        val headline = json.optString("headline", "Monthly Financial Snapshot")
        val summary = json.optString("summary", "")
        val tipsArray = json.optJSONArray("tips")
        val tips = buildList {
            if (tipsArray != null) {
                for (i in 0 until tipsArray.length()) {
                    val item = tipsArray.getJSONObject(i)
                    add(
                        SavingsTipItem(
                            title = item.optString("title", "Optimize Spending"),
                            detail = item.optString("detail", ""),
                            targetCategory = item.optString("targetCategory", "General"),
                            estimatedMonthlySaving = item.optString("estimatedMonthlySaving", ""),
                            impactLevel = item.optString("impactLevel", "Medium")
                        )
                    )
                }
            }
        }
        return PersonalizedSavingsReport(
            healthScore = healthScore,
            headline = headline,
            summary = summary,
            tips = tips
        )
    }

    fun streamCoachAnswer(contextPrompt: String): Flow<String> {
        return coachChatModel.generateContentStream(contextPrompt)
            .map { chunk -> chunk.text.orEmpty() }
    }
}
