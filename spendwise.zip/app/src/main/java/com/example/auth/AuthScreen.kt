package com.example.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.Password
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.model.FinanceFormatters
import com.example.ui.components.BrandLogoMark
import com.example.ui.components.LanguageAndThemePills
import com.example.ui.components.PrivacyPolicyDialog
import com.example.ui.components.SplashIllustrationCanvas
import com.example.ui.components.shareAppText
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.HeroGradientEnd
import com.example.ui.theme.HeroGradientStart
import com.example.ui.theme.LocalFinanceColors
import com.example.ui.theme.SplashGradientEnd
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.delay

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AuthScreen(
    language: AppLanguage,
    onToggleLanguage: () -> Unit,
    onToggleTheme: () -> Unit,
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val copy = remember(language) { AppStrings.forLanguage(language) }
    val isDark = LocalFinanceColors.current.isDark

    var isSignUpMode by rememberSaveable { mutableStateOf(false) }
    var nameInput by rememberSaveable { mutableStateOf("") }
    var phoneInput by rememberSaveable { mutableStateOf("") }
    var otpInput by rememberSaveable { mutableStateOf("") }
    var normalizedPhone by rememberSaveable { mutableStateOf("") }
    var verificationId by rememberSaveable { mutableStateOf<String?>(null) }
    var resendToken by remember { mutableStateOf<PhoneAuthProvider.ForceResendingToken?>(null) }
    var resendCountdown by rememberSaveable { mutableIntStateOf(0) }

    var isSendingOtp by remember { mutableStateOf(false) }
    var isVerifyingOtp by remember { mutableStateOf(false) }
    var isGoogleLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val anyLoading = isSendingOtp || isVerifyingOtp || isGoogleLoading

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            scope = scope,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = { /* Interactive Mobile OTP & Google Sign-In handles sign-in */ }
        )
    }

    LaunchedEffect(resendCountdown) {
        if (resendCountdown > 0) {
            delay(1000L)
            resendCountdown -= 1
        }
    }

    fun startPhoneOtpSend(isResend: Boolean) {
        errorMessage = null
        if (isSignUpMode && nameInput.trim().isEmpty()) {
            errorMessage = copy.enterYourNameError
            return
        }
        val formatted = normalizePhoneNumber(phoneInput)
        if (formatted == null) {
            errorMessage = copy.invalidMobileError
            return
        }
        normalizedPhone = formatted
        isSendingOtp = true
        sendPhoneVerificationCode(
            context = context,
            e164Phone = formatted,
            signUpName = if (isSignUpMode) nameInput.trim() else null,
            language = language,
            resendToken = if (isResend) resendToken else null,
            scope = scope,
            onCodeSent = { verId, token ->
                isSendingOtp = false
                verificationId = verId
                resendToken = token
                resendCountdown = 30
            },
            onInstantAuthSuccess = {
                isSendingOtp = false
                onAuthSuccess()
            },
            onAuthError = { msg ->
                isSendingOtp = false
                errorMessage = msg
            }
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top-right [EN / বাংলা] + [☀️ / 🌙] pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    LanguageAndThemePills(
                        language = language,
                        isDark = isDark,
                        copy = copy,
                        onToggleLanguage = onToggleLanguage,
                        onToggleTheme = onToggleTheme
                    )
                }

                // Indigo-Violet-Magenta Splash Hero Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(HeroGradientStart, HeroGradientEnd, SplashGradientEnd)
                            )
                        )
                ) {
                    Box(
                        modifier = Modifier
                            .size(150.dp)
                            .align(Alignment.TopEnd)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.09f))
                    )
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .align(Alignment.BottomStart)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SplashIllustrationCanvas()

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            BrandLogoMark(size = 44.dp)
                            Text(
                                text = copy.appTitle,
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = copy.appTagline,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.92f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SplashChip(copy.chipDailyExp)
                            SplashChip(copy.chipMonthlyInc)
                            SplashChip(copy.chipCategoryTrack)
                        }
                    }
                }

                // Sign In / Sign Up with Mobile Number + Google Sign-In Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = copy.cloudVaultBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = !isSignUpMode,
                                onClick = {
                                    if (!anyLoading) {
                                        isSignUpMode = false
                                        errorMessage = null
                                    }
                                },
                                shape = SegmentedButtonDefaults.itemShape(0, 2),
                                modifier = Modifier.testTag("auth_mode_signin_tab")
                            ) {
                                Text(copy.authTabSignIn)
                            }
                            SegmentedButton(
                                selected = isSignUpMode,
                                onClick = {
                                    if (!anyLoading) {
                                        isSignUpMode = true
                                        errorMessage = null
                                    }
                                },
                                shape = SegmentedButtonDefaults.itemShape(1, 2),
                                modifier = Modifier.testTag("auth_mode_signup_tab")
                            ) {
                                Text(copy.authTabSignUp)
                            }
                        }

                        Text(
                            text = if (isSignUpMode) copy.signUpCardTitle else copy.signInCardTitle,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = if (isSignUpMode) copy.signUpSubtitle else copy.signInSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (errorMessage != null) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer
                                ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = errorMessage.orEmpty(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                    TextButton(
                                        onClick = {
                                            errorMessage = null
                                            isGoogleLoading = true
                                            onGoogleSignInClicked(
                                                context = context,
                                                credentialManager = credentialManager,
                                                scope = scope,
                                                onAuthSuccess = {
                                                    isGoogleLoading = false
                                                    onAuthSuccess()
                                                },
                                                onAuthError = { msg ->
                                                    isGoogleLoading = false
                                                    errorMessage = msg
                                                },
                                                onAuthCancelled = {
                                                    isGoogleLoading = false
                                                }
                                            )
                                        },
                                        enabled = !anyLoading
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Login,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(copy.signInGoogleButton)
                                    }
                                }
                            }
                        }

                        val activeVerId = verificationId
                        if (activeVerId == null) {
                            if (isSignUpMode) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    label = { Text(copy.yourNameLabel) },
                                    leadingIcon = {
                                        Icon(Icons.Rounded.Person, contentDescription = null)
                                    },
                                    singleLine = true,
                                    enabled = !anyLoading,
                                    keyboardOptions = KeyboardOptions(
                                        capitalization = KeyboardCapitalization.Words
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("auth_name_input"),
                                    shape = RoundedCornerShape(14.dp)
                                )
                            }

                            OutlinedTextField(
                                value = phoneInput,
                                onValueChange = { phoneInput = it },
                                label = { Text(copy.mobileNumberLabel) },
                                placeholder = { Text("017XXXXXXXX") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.PhoneAndroid, contentDescription = null)
                                },
                                singleLine = true,
                                enabled = !anyLoading,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("auth_phone_input"),
                                shape = RoundedCornerShape(14.dp)
                            )

                            Button(
                                onClick = { startPhoneOtpSend(isResend = false) },
                                enabled = !anyLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("send_otp_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                )
                            ) {
                                if (isSendingOtp) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.5.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(copy.sendingOtpProgress, style = MaterialTheme.typography.labelLarge)
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.Sms,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(copy.sendOtpButton, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        } else {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = copy.otpSentTitle(normalizedPhone),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                )
                            }

                            OutlinedTextField(
                                value = otpInput,
                                onValueChange = { raw ->
                                    otpInput = raw.filter { it.isDigit() }.take(6)
                                },
                                label = { Text(copy.otpCodeLabel) },
                                placeholder = { Text("123456") },
                                leadingIcon = {
                                    Icon(Icons.Rounded.Password, contentDescription = null)
                                },
                                singleLine = true,
                                enabled = !anyLoading,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("otp_code_input"),
                                shape = RoundedCornerShape(14.dp)
                            )

                            Button(
                                onClick = {
                                    errorMessage = null
                                    if (otpInput.length < 6) {
                                        errorMessage = copy.invalidOtpError
                                        return@Button
                                    }
                                    isVerifyingOtp = true
                                    verifyPhoneOtpCode(
                                        verificationId = activeVerId,
                                        otpCode = otpInput,
                                        signUpName = if (isSignUpMode) nameInput.trim() else null,
                                        scope = scope,
                                        onAuthSuccess = {
                                            isVerifyingOtp = false
                                            onAuthSuccess()
                                        },
                                        onAuthError = { msg ->
                                            isVerifyingOtp = false
                                            errorMessage = msg
                                        }
                                    )
                                },
                                enabled = !anyLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("verify_otp_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                if (isVerifyingOtp) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.5.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(copy.verifyingOtpProgress, style = MaterialTheme.typography.labelLarge)
                                } else {
                                    Text(copy.verifyOtpButton, style = MaterialTheme.typography.labelLarge)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = {
                                        verificationId = null
                                        otpInput = ""
                                        errorMessage = null
                                    },
                                    enabled = !anyLoading,
                                    modifier = Modifier.testTag("change_phone_button")
                                ) {
                                    Text(copy.changeNumberButton)
                                }
                                TextButton(
                                    onClick = { startPhoneOtpSend(isResend = true) },
                                    enabled = !anyLoading && resendCountdown == 0,
                                    modifier = Modifier.testTag("resend_otp_button")
                                ) {
                                    Text(
                                        if (resendCountdown > 0) {
                                            "${copy.resendOtpButton} (${
                                                FinanceFormatters.localizeDigits(resendCountdown.toString(), language)
                                            }s)"
                                        } else {
                                            copy.resendOtpButton
                                        }
                                    )
                                }
                            }
                        }

                        // Switch Sign In / Sign Up text prompt
                        TextButton(
                            onClick = {
                                isSignUpMode = !isSignUpMode
                                errorMessage = null
                            },
                            enabled = !anyLoading,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        ) {
                            Text(
                                text = if (isSignUpMode) copy.alreadyHaveAccount else copy.newUserPrompt,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            HorizontalDivider(modifier = Modifier.weight(1f))
                            Text(
                                text = copy.orDivider,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            HorizontalDivider(modifier = Modifier.weight(1f))
                        }

                        // Google Sign-In via Credential Manager
                        OutlinedButton(
                            onClick = {
                                errorMessage = null
                                isGoogleLoading = true
                                onGoogleSignInClicked(
                                    context = context,
                                    credentialManager = credentialManager,
                                    scope = scope,
                                    onAuthSuccess = {
                                        isGoogleLoading = false
                                        onAuthSuccess()
                                    },
                                    onAuthError = { msg ->
                                        isGoogleLoading = false
                                        errorMessage = msg
                                    },
                                    onAuthCancelled = {
                                        isGoogleLoading = false
                                    }
                                )
                            },
                            enabled = !anyLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("google_sign_in_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (isGoogleLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(copy.signingInProgress, style = MaterialTheme.typography.labelLarge)
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Login,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(copy.signInGoogleButton, style = MaterialTheme.typography.labelLarge)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Fingerprint,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = copy.privacyNoticeUnderSignIn,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Bottom footer links: 📣 শেয়ার · 🔒 গোপনীয়তা নীতি
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = copy.shareLinkLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { shareAppText(context, copy) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("auth_share_link")
                    )
                    Text(
                        text = "·",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = copy.privacyPolicyLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showPrivacyDialog = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("auth_privacy_link")
                    )
                }
            }
        }
    }

    if (showPrivacyDialog) {
        PrivacyPolicyDialog(
            copy = copy,
            onDismiss = { showPrivacyDialog = false }
        )
    }
}

@Composable
private fun SplashChip(text: String) {
    Surface(
        color = Color.White.copy(alpha = 0.22f),
        shape = RoundedCornerShape(20.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
