package com.example.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.ui.i18n.AppLanguage
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.auth.userProfileChangeRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

private const val TAG = "SpendWiseAuth"

/**
 * Holds a freshly entered Sign-Up display name across AuthStateListener recomposition
 * while FirebaseUser.updateProfile completes asynchronously.
 */
object PendingAuthProfile {
    @Volatile
    var displayName: String? = null
}

fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        trySend(firebaseAuth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

/**
 * Normalizes Bangladeshi 11-digit numbers (01XXXXXXXXX -> +8801XXXXXXXXX)
 * or validates international E.164 numbers (+[country][number]).
 */
fun normalizePhoneNumber(rawInput: String): String? {
    val cleaned = rawInput.trim()
        .replace(" ", "")
        .replace("-", "")
        .replace("(", "")
        .replace(")", "")
    val normalized = when {
        Regex("^01[3-9][0-9]{8}$").matches(cleaned) -> "+880${cleaned.substring(1)}"
        Regex("^8801[3-9][0-9]{8}$").matches(cleaned) -> "+$cleaned"
        Regex("^\\+[1-9][0-9]{7,14}$").matches(cleaned) -> cleaned
        else -> null
    }
    return normalized
}

fun sendPhoneVerificationCode(
    context: Context,
    e164Phone: String,
    signUpName: String?,
    language: AppLanguage,
    resendToken: PhoneAuthProvider.ForceResendingToken? = null,
    scope: CoroutineScope,
    onCodeSent: (verificationId: String, token: PhoneAuthProvider.ForceResendingToken) -> Unit,
    onInstantAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit
) {
    val activity = context as? Activity
    if (activity == null) {
        onAuthError("Unable to launch phone verification from non-Activity context.")
        return
    }

    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            signInWithPhoneCredential(
                credential = credential,
                signUpName = signUpName,
                scope = scope,
                onAuthSuccess = onInstantAuthSuccess,
                onAuthError = onAuthError
            )
        }

        override fun onVerificationFailed(e: FirebaseException) {
            val rawMessage = e.message.orEmpty()
            val errorCode = (e as? FirebaseAuthException)?.errorCode.orEmpty()
            val isSmsRegionBlocked = rawMessage.contains("17006") ||
                rawMessage.contains("region enabled", ignoreCase = true) ||
                rawMessage.contains("SMS unable to be sent", ignoreCase = true)
            val isProviderDisabled = errorCode == "ERROR_OPERATION_NOT_ALLOWED" ||
                rawMessage.contains("operation is not allowed", ignoreCase = true)

            if (isSmsRegionBlocked || isProviderDisabled) {
                Log.w(TAG, "Phone verification blocked by Firebase Console config ($errorCode): $rawMessage")
            } else {
                Log.w(TAG, "Phone verification failed ($errorCode): $rawMessage", e)
            }

            val msg = when {
                isSmsRegionBlocked -> {
                    if (language == AppLanguage.BN) {
                        "Firebase Console-এ এই দেশের SMS রিজিয়ন (Bangladesh +880) চালু করা হয়নি। Authentication → Settings → SMS region policy-তে Bangladesh (+880) অনুমোদন করুন (এবং Phone provider চালু রাখুন)। অথবা নিচের Google বাটনে ট্যাপ করে এখনই প্রবেশ করুন।"
                    } else {
                        "SMS OTP is blocked for this region in Firebase Console. Enable Bangladesh (+880) under Authentication → Settings → SMS region policy (and Phone sign-in provider), or tap 'Sign in with Google' below to continue right away."
                    }
                }
                isProviderDisabled -> {
                    if (language == AppLanguage.BN) {
                        "Firebase Console-এ Phone Sign-In চালু করা হয়নি (Authentication → Sign-in method → Phone → Enable)। অথবা এখনই Google দিয়ে প্রবেশ করুন।"
                    } else {
                        "Phone Sign-In is disabled in Firebase Console (Authentication → Sign-in method → Phone → Enable), or use Google Sign-In below."
                    }
                }
                e is FirebaseTooManyRequestsException -> {
                    if (language == AppLanguage.BN) {
                        "অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"
                    } else {
                        "Too many verification requests. Please wait a moment and try again."
                    }
                }
                else -> e.localizedMessage ?: if (language == AppLanguage.BN) {
                    "মোবাইল নম্বর যাচাই ব্যর্থ হয়েছে।"
                } else {
                    "Phone verification failed. Please try again."
                }
            }
            onAuthError(msg)
        }

        override fun onCodeSent(
            verificationId: String,
            token: PhoneAuthProvider.ForceResendingToken
        ) {
            onCodeSent(verificationId, token)
        }
    }

    val builder = PhoneAuthOptions.newBuilder(Firebase.auth)
        .setPhoneNumber(e164Phone)
        .setTimeout(60L, TimeUnit.SECONDS)
        .setActivity(activity)
        .setCallbacks(callbacks)

    if (resendToken != null) {
        builder.setForceResendingToken(resendToken)
    }

    PhoneAuthProvider.verifyPhoneNumber(builder.build())
}

fun verifyPhoneOtpCode(
    verificationId: String,
    otpCode: String,
    signUpName: String?,
    scope: CoroutineScope,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit
) {
    val cleanCode = otpCode.trim()
    val credential = PhoneAuthProvider.getCredential(verificationId, cleanCode)
    signInWithPhoneCredential(
        credential = credential,
        signUpName = signUpName,
        scope = scope,
        onAuthSuccess = onAuthSuccess,
        onAuthError = onAuthError
    )
}

private fun signInWithPhoneCredential(
    credential: PhoneAuthCredential,
    signUpName: String?,
    scope: CoroutineScope,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit
) {
    val cleanName = signUpName?.trim().orEmpty()
    if (cleanName.isNotEmpty()) {
        PendingAuthProfile.displayName = cleanName
    }
    scope.launch {
        try {
            withContext(NonCancellable) {
                val result = Firebase.auth.signInWithCredential(credential).await()
                val user = result.user
                if (user != null && cleanName.isNotEmpty()) {
                    runCatching {
                        user.updateProfile(
                            userProfileChangeRequest {
                                displayName = cleanName
                            }
                        ).await()
                        user.reload().await()
                    }
                }
            }
            onAuthSuccess()
        } catch (e: Exception) {
            PendingAuthProfile.displayName = null
            Log.e(TAG, "Phone OTP sign-in failed", e)
            onAuthError(e.localizedMessage ?: "Invalid verification code. Please try again.")
        }
    }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onUnauthenticated()
        return
    }
    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val cred = credentialManager.getCredential(context, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    onAuthCancelled: () -> Unit
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
        return
    }
    val activity = context as? Activity
    if (activity == null) {
        onAuthError("Unable to launch sign-in from non-Activity context.")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val cred = credentialManager.getCredential(activity, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type returned.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Sign in failed. Please try again.")
        }
    }
}

fun signOutUser(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {}
) {
    PendingAuthProfile.displayName = null
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w(TAG, "Failed to clear credential state: ${e.message}")
            } finally {
                Firebase.auth.signOut()
                onSignOutComplete()
            }
        }
    }
}
